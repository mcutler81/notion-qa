# Wrap Archive

> *Full decks from Hinge’s bi-weekly company All Hands*
> 

---

<aside>
<img src="https://www.notion.so/icons/map-pin_purple.svg" alt="https://www.notion.so/icons/map-pin_purple.svg" width="40px" /> **MOST RECENT DECK: [December 14](https://docs.google.com/presentation/d/1ERA4Ye6HBVNpr6dN1z6NOzP-HJy9DId5rCeVySSaU-s/edit)**
Comp and Bonuses Q&A | @Angel Franklin 
Machine Learning Platform Overview | @Lisa Ren 
Wrap Review | @Kristen Lowe

</aside>

## 2022 Wrap Presentations

### Q1 (Jan-Mar)

| Date  | Content |
| --- | --- |
| https://docs.google.com/presentation/d/1m_XotLIkkNA1TvjAqtt5c98a1zUISyf3r8LowarjFK4/edit?usp=sharing | Internal Comms strategy, Eurotrip update, EE strategy |
| https://docs.google.com/presentation/d/1m-ZVguUzwrcolCOilZ5xDnMPQMqGDZBOmVzrEsbJjfQ/edit  |  Forecast updates, Profiles 3.0, Quarterly Mental Health Data Story |
| https://docs.google.com/presentation/d/1FTvc3LjbRW_B3LXZAfNAPwaXAR8A7lTl3EdlhV6f0l0/edit | RTO logistics, Gen Leap strategy first look, Comp & leveling adjustments |
| https://docs.google.com/presentation/d/1q_DbrngJ2g4MIvaDDILVoXG0Oikqfgrl27MUqIRS16A/edit#slide=id.g10caf0d52a3_0_2717 | Evolving groups, Intranet updates, QA update, Video prompts preview |
| https://docs.google.com/presentation/d/1STHQ8T9dOv3Gwkr-SbQf1m6lSOMYqklfPpdhIfp-nIw/edit#slide=id.g10caf0d52a3_0_2717 | Promotions, Profiles 3.0, Health metric dashboards |

### Q2 (Apr-Jun)

| Date  | Content |
| --- | --- |
| https://docs.google.com/presentation/d/1ZCfPVDXZPXS7GHaocwUusI5jRuU76Nd8Yh9gsx-HKnE/edit#slide=id.g10caf0d52a3_0_2717 | Hybrid Work  |
| https://docs.google.com/presentation/d/1BenwtpeFudH7LLu5nhyoAzp0rPrp2yJ1o1LtN1qqBxo/edit#slide=id.g10caf0d52a3_0_2717 | Evolving Groups |
| https://docs.google.com/presentation/d/1inuheVnpeFueOttUmojYQPl7weKQa7ae66ByDc0Cj9k/edit#slide=id.g10caf0d52a3_0_2717 | Gen Leap update and NFAQs first look |
| https://docs.google.com/presentation/d/13qhZ3xckwPVYZFG2iwTQosgvSobE8JPnAiYuizsdgEo/edit#slide=id.g10caf0d52a3_0_2717 | Culture at Scale update: TA x DEI  |
| https://docs.google.com/presentation/d/14M6_jCmircblFpqBGJVivYpiJ4Xge_HQOlD2ZP-uEZs/edit#slide=id.g10caf0d52a3_0_2717 | Trust & Safety 2.0 reveal |
| https://docs.google.com/presentation/d/1Xgg6vDFF07agzceZPUCgwYtZTibTGb7z2d180Fu1GZQ/edit | Mid-Year Review (MYR) |

### Q3 (Jul-Sep)

| Date  | Content |
| --- | --- |
| https://docs.google.com/presentation/d/1cQGaE0v9YMqQdXJ7hRhTxomU3vQqCcSNV66G1Gft3BE/edit#slide=id.g10caf0d52a3_0_2717 | Leadership team update, Data capture update, Evolving groups |
| https://docs.google.com/presentation/d/1ukDI7a1b93sbvNaMKFnqFRKi65isAJitx_fXhRdkDPE/edit#slide=id.g13f9a0dd8c3_7_132 | Promotions, Intern presentations, NFAQ launch |
| https://docs.google.com/presentation/d/1dVN3_lFuQoFFlCJljC8BED_642YT0a15YyzaphxktGA/edit#slide=id.g142bfad1518_0_1141 | Future of Work and 2022/2023 RTO Policy |
| https://docs.google.com/presentation/d/14SSTm466NB7abr0WjLu8WWktQyyz3JMiGdu4Lh96d7Y/edit#slide=id.g10caf0d52a3_0_2717 | Welcome back to office, Merch update, Vibras month  |
| https://docs.google.com/presentation/d/1As3Oa5lswijiXmOi_Th_6MZB8h-hk4oyNjU700vP2Tc/edit#slide=id.g10caf0d52a3_0_2717 | Q2 market insights, Product update (video, profile hub, international appeals, NST) |

### Q4 (Oct-Dec)

| Date  | Content |
| --- | --- |
| https://docs.google.com/presentation/d/1OWwz2i2Gvbt1RP6Ecw05dvM3IJ_T3IzpW5rqU7K2ngM/edit#slide=id.g10caf0d52a3_0_2717 | 2023 APM plan, Platform team intro, Gansevoort update |
| https://docs.google.com/presentation/d/1mL1FYD1DwRUcEMfPB3SdTaj-4ghsXP2AkL1428aEtwY/edit#slide=id.g10caf0d52a3_0_2717 | Merch store, Gen Leap update |
| https://docs.google.com/presentation/d/1_ErbU4LX_QICd3Jma-PVva2CWtXhiJ2sMW2IMBxzrSI/edit#slide=id.g18d22f78250_0_384 | NST Announcement, Pay & Comp Review |
| https://docs.google.com/presentation/d/1KeagKIKqGZbAtBetcRkz9f_cpxEeEZ3yAmqGaiiXzUQ/edit#slide=id.g10caf0d52a3_0_2717 | Bad Actors Case Study, Holiday Party info, EES Preview, Performance Management |
| https://docs.google.com/presentation/d/1ERA4Ye6HBVNpr6dN1z6NOzP-HJy9DId5rCeVySSaU-s/edit#slide=id.g10caf0d52a3_0_3117 | Machine Learning Platform update, Wrap Review |

## Old

### **2021**

- **Q1**
    
    [1.28.2021](https://docs.google.com/presentation/d/1OD6niTnWNFgOuJOGpzu_xcxRqsP5Qml-FgoVuUM9gk0/edit#slide=id.gb90fef8081_0_104)
    
    [2.11.2021](https://www.google.com/url?sa=t&rct=j&esrc=s&source=appssearch&uact=8&cd=8&cad=rja&q&sig2=F6vv7HfknoE3DOsejS7Aow&ved=0ahUKEwib2JrW1YbvAhWMojcKHXuoCXo4ABABKAgwCA&url=https://drive.google.com/a/hinge.co/open?id%3D1GxEdXBcLzUzgbNrN3HrzIFL8L1_a3JeRA-sd1sfDpI4%26usp%3Dchrome_omnibox&usg=AOvVaw3eZFEakAdmOt4ucxL7Incs)
    
    [2.25.2021](https://docs.google.com/presentation/d/1vn2wq8am3zvVl_8a9oVoCRJUVYE_Yx-2SqZ3ASy8d18/edit#slide=id.gb90fef8081_0_104)
    

### **2020**

- **Q1**
    
    [2.6.2020](https://docs.google.com/presentation/d/1f1d1rhsY_c2Nxzw2eMV1MqFHn0lnIUjflfnF2NQo0Nk/edit#slide=id.g7d56eee063_0_2)
    
    [2.12.2020](https://drive.google.com/open?id=1HJ05RoEBKn_S09ToukIIhD0GOWn3WG-KwhJEWeOUn5U)
    
    [2.27.2020](https://drive.google.com/open?id=1ttITa6ExNaZRHxw3YWE-rwzCFtlflgInl3Y6tb7_wD0)
    
    [3.5.2020](https://drive.google.com/open?id=1S6yisiZJYvEldVKp3Y75V_1vDPfjihLeYmCo6uZ1dQY)
    
    [3.12.2020](https://drive.google.com/open?id=1_VQ1RhROTvSRzRhEByq0N7r2oDdt9x2h6zTcQzt1FiE)
    
    [3.19.2020](https://drive.google.com/open?id=19k0j70y2am1IrrLJlorYM8uwv-QR3M4D6Hta0SbHmfE)
    
    [3.26.2020](https://drive.google.com/open?id=1QW_CbLQeg6qLyQCgHRB1UAJ4Nt15ejR4JcKptLs7xeo)
    
- **Q2**
    
    [4.2.2020](https://drive.google.com/open?id=1h2kcvX7D9NyEEe0HcinOMS7c4-LivZWQADIC1Z4Hkgc)
    
    [4.9.2020](https://drive.google.com/open?id=1GGIIuTVcCl0drRrO9XtpmRoXTmZQHjToF-1biEAqWHA)
    
    [4.16.2020](https://drive.google.com/open?id=1wesjwSHY5I_CUdioc2B5Zwjnb9VlLAqrXRD7rb7Sk30)
    
    [4.23.2020](https://drive.google.com/open?id=15sLKJNa_ign1XHhdIwY32mdqeM5f8bi2CEHlIFei7dg)
    
    [4.30.2020](https://drive.google.com/open?id=16eVbO4fsvV6FOzH7h6MBUwRTOh0IWl30jl1JjhzCEAM)
    
    [5.7.2020](https://drive.google.com/open?id=1T_PpjguJjD44V-KcbuMsARVrbCZX6fB6zTrBd_819ig)
    
    [5.14.2020](https://drive.google.com/open?id=1CD7lt5TqfCTEf06VW3oTOf4DmFrpB69dozsrGN03ka4)
    
    [5.28.2020](https://drive.google.com/open?id=1L_SJNsVx0FUXZKOKu-9q-072Z7sGNc73ZaoU5tn2VA0)
    
    [6.4.2020](https://drive.google.com/open?id=1Y_hWf_r9PUN4xym9HpHIKPEwUzPDsKlGbeGrznxzsk0)
    
    [6.18.2020](https://docs.google.com/presentation/d/14Z0ol86zgh2h6fevj13XJIXyBSXNlZgHAPEGs45apGs/edit#slide=id.g7e01b3c6da_5_0)
    
- **Q3**
    
    [7.2.2020](https://docs.google.com/presentation/d/1OQneOJHPmnSoecdW3ec25KUaj5P6bCLqx5ybqTJ6iA0/edit?usp=sharing)
    
    [7.16.2020](https://docs.google.com/presentation/d/1-T0yjfmI8EyXoiFN0n0R5Qrczvnf1oyh22yF-09gxR4/edit?usp=sharing)
    
    [8.13.2020](https://docs.google.com/presentation/d/1M_ANPw8xmpEQSGPveei1aeeFokFURFMHBFN9jQFsLQU/edit?usp=sharing)
    
    [8.25.2020](https://docs.google.com/presentation/d/1ktGVr637SedYWeGoBziNC2st6wAsd6tg3F01s9SiB2w/edit?usp=sharing)
    
    [9.10.2020](https://docs.google.com/presentation/d/1ts0xunWO6ksG2OrUCShK420rAPCuoBrIeDAbUuGicUk/edit?usp=sharing)
    
    [9.24.2020](https://docs.google.com/presentation/d/1As4ZXqKOuUgRoTzo1xJyYsHFk70KIfuMfTXx_xIBgig/edit?usp=sharing)
    
- **Q4**
    
    [10.8.2020](https://docs.google.com/presentation/d/1xqCGL7k_LMRS1V7QsziHaUUg6sQ9UFq99OsG-x1JfyQ/edit?usp=sharing)
    
    [10.22.2020](https://docs.google.com/presentation/d/14QikpLbSHVbIL0ys6IVBCCIxe7gX35DAOplrnLG1sT0/edit#slide=id.g8d91f6b581_0_475)
    
    [11.19.2020](https://docs.google.com/presentation/d/1dumCc85T8xEIDaFujDAd-gS7sQxU-2-0VFbWW6tGyWo/edit?usp=sharing)