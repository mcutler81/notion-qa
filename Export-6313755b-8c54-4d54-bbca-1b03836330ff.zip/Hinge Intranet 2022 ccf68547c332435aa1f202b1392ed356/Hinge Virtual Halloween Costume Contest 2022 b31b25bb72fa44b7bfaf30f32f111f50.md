# Hinge Virtual Halloween Costume Contest 2022

### How do you think the Sanderson Sisters would delete Hingie if they found love?

![Halloween Hingie.png](Hinge%20Virtual%20Halloween%20Costume%20Contest%202022%20b31b25bb72fa44b7bfaf30f32f111f50/Halloween_Hingie.png)

🎃 For those around the world who participate in Halloween, Hinge is holding a virtual costume contest!

The way it works is simple.

## ℹ️ How to Enter

Step One -

📸 Snap a photo which fits one of the following categories:

1. *Best Overall Costume*
2. *Funniest Costume*
3. *Scariest Costume*
4. *Most On-Brand for Hinge Costume*
5. *Best Duo or Group Costume*
6. *Best Family/Chosen Family Member Costume (12 or under)*
7. *Best Pet costume*

Step Two -

⬆️ Upload your photo in the THREAD of the appropriate post in the #2022_halloween_costume_contest Slack channel.

## ⏰ Contest Submission Window

**From Wednesday October 26th through Tuesday November 1st, 2:00pm EDT.**

## 👩🏽‍⚖️👨🏼‍⚖️🧑🏻‍⚖️  Judges

An expert panel of cross functional judges (to be determined, wanna volunteer?) will choose the winners and general Hingefolk are welcome to up vote their favorite photos in the #2022_halloween_costume_contest Slack channel to help influence the judges decision.

## 🏆 Prizes

Each Category winner will yield a $50 Amazon Gift Card

## ❓FAQs

- May I submit more than one costume/category?
    
    Yes
    
- Does the costume have to be from this year?
    
    Yes. Costumes need to have been worn and photographed sometime between Friday, October 21st and Monday, October 31st.
    
- Who is eligible to compete?
    
    Categories 1-4 are for Hinge employees
    
    Category 5 must include one Hinge employee
    
    Categories 6 and 7 are open as long as there is a reasonable connection to a Hinge employee
    
- What if I don’t want to participate in this but still want to get something?
    
    There are some Halloween treats available at the lobby entry on 3, 4, 5 and 6 starting Tuesday 10/25 in anticipation of the holiday should you choose to come in.
    

![Happy Halloween.png](Hinge%20Virtual%20Halloween%20Costume%20Contest%202022%20b31b25bb72fa44b7bfaf30f32f111f50/Happy_Halloween.png)