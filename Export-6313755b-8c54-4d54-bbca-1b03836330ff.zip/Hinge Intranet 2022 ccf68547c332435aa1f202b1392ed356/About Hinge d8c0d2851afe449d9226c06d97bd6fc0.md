# About Hinge

---

## Who We Are

### **History**

**The Beginning**

Hinge’s history begins in August of 2012, when Justin McLeod first founding the company with the intention of building a dating app that could break away from the addictive, swipe-centric world of existing dating apps to connect people in real, lasting relationships.

**The Middle** 

Between 2012 and 2017, Hinge survived numerous ups and downs before finally ditching the original swiping design to create a whole new app in October of 2017. 

Not long after, Hinge was acquired by Match Group in February of 2018 and also introduced the world to Hinge, the icon 

**The Present**

Today, Hinge is still on a mission to create real connection by designing the most effective, 3D app experience and leading the way with innovative features like voice and video prompts. 

### Mission

We believe anyone looking for love should be able to find it

### Vision

The leading innovator in intentioned dating for all

## Culture at Hinge

**What is culture?**

To us, culture is simply “how we do things.” At Hinge, we make a point of being explicit and thoughtful about how we do things because if we aren’t, we’ll either end up doing things in ways we don’t like or, worse, have no clear way of doing things at all.

Having common goals, values, norms and practices is what binds us together as a group of smart, independent thinkers into a brilliant, collaborative team capable of accomplishing what we couldn’t dream of doing alone. It also makes working together way more fun.

We expect you to hold yourself, as well as your teammates – including management and leadership – accountable to these principles. You can do this through feedback to teammates, through questions at Town Hall and, of course, mindful application of our core principles to your own work.

Last, please note that we consider this to be a living document. It represents the collective wisdom learned through our experiences but only up to this point. Our culture must continue to evolve as we learn and as the company changes and grows. We always appreciate and consider feedback about these principles and practices. Most importantly, thank you for being part of our community!

*Justin McLeod*

*Hinge Founder and CEO*

### Values

*Our “ACE” values unite us as a team and keep us true to our mission.*

**Authenticity.** We share, never hide, our words, actions and intentions.

> Transparency, candor and humility allow us to focus on delivering outstanding results without getting distracted by ego, gossip or politics.
> 

**Courage.** We embrace lofty goals and tough challenges.

> Breakthroughs require our willingness to take risks. We strive toward audacious goals, expecting and persevering through setbacks and failures along the way.
> 

**Empathy.** We deeply consider the perspective of others.

> We remember we’re all human beings first. We keep in mind who we’re serving. We listen humbly and openly. We speak and act with kindness and care.
> 

### Principles

*Our core principles are our values in action. Authenticity, courage and empathy can seem abstract, which is why we translate them into these specific and concrete ways we live them in our day to day work. They govern the way we work at Hinge across the entire organization.*

**Designed to be Deleted.** 

> Hinge exists to help our users find love. We do that by setting up great dates.
> 

**Guided by Principles.** 

> We create principles to get clear on what matters and why. Principles help us move faster, resolve conflicts and make better decisions.
> 

**Radical trust.** 

> We are trusted to own our projects and make the decisions that shape them. We maintain that trust through open communication.
> 

**People with Heart.** 

> We hire team players who embody our core values. Once here, we show up with heart as active co-creators of Hinge culture.
> 

**Love the Leap.** 

> We set big, audacious goals and take risks to achieve them. Failure—and learning from it—is a part of the model.
> 

<aside>
📌 *To learn more about our principles, watch [this interview](https://vimeo.com/624648104) with Justin. The password is Hinge2021*

</aside>

---

*Note: While the principles outlined here help us understand how we work together at Hinge, as part of Match Group, we adhere to and abide under the Match Group Policies and Procedures. See link below:*

[Match Group U.S. Policies and Procedures Manual August 2019 (1).pdf](About%20Hinge%20d8c0d2851afe449d9226c06d97bd6fc0/Match_Group_U.S._Policies_and_Procedures_Manual_August_2019_(1).pdf)