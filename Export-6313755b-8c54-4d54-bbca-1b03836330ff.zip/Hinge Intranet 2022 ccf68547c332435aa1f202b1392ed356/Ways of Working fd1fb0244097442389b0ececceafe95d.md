# Ways of Working

> *Best practices, templates, and guidance for how we work at Hinge*
> 

---

## About

These pages include guidance and resources related to How Hinge Works! 

## **Contents**

[Hybrid Work @ Hinge](Ways%20of%20Working%20fd1fb0244097442389b0ececceafe95d/Hybrid%20Work%20@%20Hinge%201628375e72cd4d3bb2ec372a379fbae3.md)

[Company Calendars](Ways%20of%20Working%20fd1fb0244097442389b0ececceafe95d/Company%20Calendars%20fa99a5358d934c9e86e81b8e69e6f7c9.md)

[Vendor / Tool Directory](Ways%20of%20Working%20fd1fb0244097442389b0ececceafe95d/Vendor%20Tool%20Directory%20aeb998bd2aa842d88958ffa9b332cc7d.md)

[Communication Norms & Practices](Ways%20of%20Working%20fd1fb0244097442389b0ececceafe95d/Communication%20Norms%20&%20Practices%20084e015e4fbc480b8f5557810dc85c5f.md)

[One-on-Ones](Ways%20of%20Working%20fd1fb0244097442389b0ececceafe95d/One-on-Ones%20eaca299f975a4abd8968d5dd9e393467.md)

[Feedback](Ways%20of%20Working%20fd1fb0244097442389b0ececceafe95d/Feedback%2005e0b3f70b4e4a2883b15918640879c4.md)

[OKRs](Ways%20of%20Working%20fd1fb0244097442389b0ececceafe95d/OKRs%20137851b9a0ad475d80cdeb3265e20358.md)

[Post-Mortems](Ways%20of%20Working%20fd1fb0244097442389b0ececceafe95d/Post-Mortems%2078d6c2b25da341e7b110fff274c02286.md)

[Planning](Ways%20of%20Working%20fd1fb0244097442389b0ececceafe95d/Planning%201800bd56e3424b26afc51317894702cb.md)

---