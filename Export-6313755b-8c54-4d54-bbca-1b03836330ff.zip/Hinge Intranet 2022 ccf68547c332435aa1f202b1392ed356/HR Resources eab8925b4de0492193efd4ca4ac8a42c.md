# HR Resources

> *Tools and guides to support the Hinge employee experience*
> 

---

## For Everyone

[I'm new here - onboard me!](HR%20Resources%20eab8925b4de0492193efd4ca4ac8a42c/I'm%20new%20here%20-%20onboard%20me!%202b67717b272441de82a61286aa7b016c.md)

[Compensation](HR%20Resources%20eab8925b4de0492193efd4ca4ac8a42c/Compensation%2064297370b1cc4b268d966648a83f0bf7.md)

[Performance Management](HR%20Resources%20eab8925b4de0492193efd4ca4ac8a42c/Performance%20Management%208e75cb5447e549fb9792ac990441ed38.md)

[Employee Perks](HR%20Resources%20eab8925b4de0492193efd4ca4ac8a42c/Employee%20Perks%208927f69c7c55405d8d6c7ed610cd2a89.md)

[Workday](HR%20Resources%20eab8925b4de0492193efd4ca4ac8a42c/Workday%20c5f2f11c9ef44a36b4d1d7c44a5e8d22.md)

[Benefits](HR%20Resources%20eab8925b4de0492193efd4ca4ac8a42c/Benefits%2033741f6b5bd14139a2d7b43e54dc4cb6.md)

[Leave & Immigration](HR%20Resources%20eab8925b4de0492193efd4ca4ac8a42c/Leave%20&%20Immigration%204c1a2b7d63dd492ab60e9b71fae1823b.md)

[Time Off](HR%20Resources%20eab8925b4de0492193efd4ca4ac8a42c/Time%20Off%20e4da47b65cc146e69170dca888d8750c.md)

[Employee Engagement Survey](HR%20Resources%20eab8925b4de0492193efd4ca4ac8a42c/Employee%20Engagement%20Survey%20dcab56bda3674bb584e91ee1fc5cad5f.md)

[Hiring & Recruiting](HR%20Resources%20eab8925b4de0492193efd4ca4ac8a42c/Hiring%20&%20Recruiting%206104c3f95ef7423b8b84ab5485423439.md)

[Career Growth](HR%20Resources%20eab8925b4de0492193efd4ca4ac8a42c/Career%20Growth%206ddabb5e49e4420d9fecc70c72a9c037.md)

[Learning + Development](HR%20Resources%20eab8925b4de0492193efd4ca4ac8a42c/Learning%20+%20Development%206f37aff54a3b4429b36e820fdc2a84bf.md)

[Expenses](HR%20Resources%20eab8925b4de0492193efd4ca4ac8a42c/Expenses%20b9f809265bf842c1921437ae675d5a66.md)

[Merch](HR%20Resources%20eab8925b4de0492193efd4ca4ac8a42c/Merch%20ee7c736d6f7549998f0c3ee0ae9d48f7.md)

[New Vendor Process](HR%20Resources%20eab8925b4de0492193efd4ca4ac8a42c/New%20Vendor%20Process%2090ee35976fae42c792d7b0cd14de512f.md)

[IT Basics & FAQ](HR%20Resources%20eab8925b4de0492193efd4ca4ac8a42c/IT%20Basics%20&%20FAQ%201f3c185653f943a6bf796e40c8a08e7b.md)

[Employment Verification](HR%20Resources%20eab8925b4de0492193efd4ca4ac8a42c/Employment%20Verification%206738430c21814c70bb8954d39971dc2b.md)

## For Managers

[Team Budgets](HR%20Resources%20eab8925b4de0492193efd4ca4ac8a42c/Team%20Budgets%2021b961502c704ac993c87c50efde104f.md)