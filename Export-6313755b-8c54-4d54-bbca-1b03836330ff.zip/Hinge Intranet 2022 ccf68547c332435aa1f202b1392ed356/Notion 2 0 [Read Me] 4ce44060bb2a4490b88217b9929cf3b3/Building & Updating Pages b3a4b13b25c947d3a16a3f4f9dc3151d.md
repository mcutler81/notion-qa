# Building & Updating Pages

---

*Notion 2.0 is glowing up with standardized page templates, design norms, and maintenance norms. While we update and create content in Notion 2.0, please reference the following resources for building/updating pages. For design guidance, check out:*

[**Style & Design Rules**](Style%20&%20Design%20Rules%202a541445689e44d49a15de6a44cec452.md)

## **Page Types**

**Nav Pages**

> The 7 highest-level pages in the navigational pane. These pages are the only ones at this navigational level and can only be created and edited by Intranet owners.
(*About Hinge, Office, Groups & Organization, Departments, Norms & Resources, HR Resources, Archives*)
> 

**Home Pages**

> The highest page level for a department, group, workstream, or topic. These pages should be created using the the appropriate templates (below) and can only be created/edited by designated page owners.
> 

**Verified Pages**

> Any page that has been fully designed, developed, and reviewed for use in Notion 2.0. Verified pages should follow all Page Design norms (below) and have a designated owner.
> 

**Working Pages**

> Working pages are pages that are currently under construction in Notion 2.0 and have not been verified. Working pages have a callout at the top with a construction sign like the one below that indicates they’re still being built. Please keep these on your pages until they are done. Anyone can create a working page for verification.
> 
> 
> <aside>
> <img src="https://cdn-icons.flaticon.com/png/512/3586/premium/3586685.png?token=exp=1646345797~hmac=3513849be6b8866a8c5a89ef537c190e" alt="https://cdn-icons.flaticon.com/png/512/3586/premium/3586685.png?token=exp=1646345797~hmac=3513849be6b8866a8c5a89ef537c190e" width="40px" /> WIP
> 
> </aside>
> 

## **Page Templates**

*The following templates outline the block styles and different content for standardized pages.*

[Basic Page [Template]](Building%20&%20Updating%20Pages%20b3a4b13b25c947d3a16a3f4f9dc3151d/Basic%20Page%20%5BTemplate%5D%206c6d092e593341b3b695c33797faa364.md)

[Group Home Page [Template]](Building%20&%20Updating%20Pages%20b3a4b13b25c947d3a16a3f4f9dc3151d/Group%20Home%20Page%20%5BTemplate%5D%20e69b8794da6342c4bfab56c413630275.md)

[**Workstream Home Page [Template]**](Building%20&%20Updating%20Pages%20b3a4b13b25c947d3a16a3f4f9dc3151d/Workstream%20Home%20Page%20%5BTemplate%5D%2035d72b809d7a4e80b4ac3031eb20fd84.md)

[Workstream Hub [Template]](Building%20&%20Updating%20Pages%20b3a4b13b25c947d3a16a3f4f9dc3151d/Workstream%20Home%20Page%20%5BTemplate%5D%2035d72b809d7a4e80b4ac3031eb20fd84/Workstream%20Hub%20%5BTemplate%5D%2061310602711644d397aeeecb093a0b72.md)

[Research Center [Template] - Coming Soon](Building%20&%20Updating%20Pages%20b3a4b13b25c947d3a16a3f4f9dc3151d/Workstream%20Home%20Page%20%5BTemplate%5D%2035d72b809d7a4e80b4ac3031eb20fd84/Research%20Center%20%5BTemplate%5D%20-%20Coming%20Soon%206f6df59b2c1748679dd09bd4ec2e908a.md)

[Department Page [Template] - Coming Soon](Building%20&%20Updating%20Pages%20b3a4b13b25c947d3a16a3f4f9dc3151d/Department%20Page%20%5BTemplate%5D%20-%20Coming%20Soon%2004360bee2d9540eea3ff9b915c0d7ed7.md)

## Page Design

*The Basic Page Template (above) should support most page designs. If you need to build a custom page, please follow the guidance below.*

### Setting Up Pages From Scratch

1. Name your page something short and intuitive.
2. Create a cover by hovering your mouse above the title and selecting “add cover.” This will generate a random cover. Please change the color to the light peach color used at the top of this page. Pages with that color are official Intranet pages.
3. Add an icon by hovering your mouse above the title again and clicking “add icon.” Click on the random icon that appears and replace it with a **black and white icon**. I recommend using icons from [Flat Icon](https://www.flaticon.com/), which allow you to insert the icon as a link by copying its image address.
4. Create a divider line at the top of the page (in a new text line, enter “/divider”).  

## FAQ

- **Departments vs Groups**

---

**Questions?** Reach out to Kristen Lowe on Slack or at kristen.lowe@hinge.co

[Department Home [Template] ](Building%20&%20Updating%20Pages%20b3a4b13b25c947d3a16a3f4f9dc3151d/Department%20Home%20%5BTemplate%5D%20f28da78b6e574d1bb951c0f6c6d0d50a.md)