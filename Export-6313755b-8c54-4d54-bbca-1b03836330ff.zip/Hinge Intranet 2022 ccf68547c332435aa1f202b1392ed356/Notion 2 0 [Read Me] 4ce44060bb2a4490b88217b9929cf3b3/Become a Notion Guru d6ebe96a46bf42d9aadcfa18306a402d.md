# Become a Notion Guru

---

Become a better Notion user by taking some time to learn about the different pieces & productivity tips. If you are Notion curious, review the following links and shortcuts that can make using Notion feel fun and easy.

## Notion Basics

*Block types, basic steps, and helpful tips*

[47 Helpful Notion Tips](https://curiousrefuge.com/blog/notion-tips)

[“The Only Notion Guide You’ll Ever Need”](https://radreads.co/notion-tutorial/)

[“The 33 Best Notion Tips”](https://www.apptuts.net/en/tutorial/mac/notion-tips-and-tricks-best/)

## Community Support

*Resources for becoming a pro*

[Sign up to be a Notion Champion](https://www.notion.so/Notion-Champions-20f977eb5fdd40d4a7a396f1742c3ea5)

[Browse the Notion Reddit](https://www.reddit.com/r/Notion/) 

## Keyboard Shortcuts

*In case you really care about ~never touching your mouse~*

## To Navigate

- **Open a search:** Press **`cmd/ctrl`** + **`P`**
- **Go back a page:** Press **`cmd/ctrl`** + **`[`**
- **Go forward a page:** Press **`cmd/ctrl`** + **`]`**
- **Toggle between light and dark mode:** Press **`cmd/ctrl`** + **`shift`** + **`L`**

## To Create/Change Blocks

- **New Line**: Press **`enter`** to insert a line of text.
- **Link Break within Block:** Press **`shift`** + **`enter`**
- **Comment:**  Press **`cmd/ctrl`** + **`shift`** + **`M`**
- **Nest Content:** Press **`tab`** to indent. When you indent, you're nesting that block inside the block above it.
- **Convert (Turn) Block:** Type **`/turn`** at the beginning or end of a block and select from list
- **Duplicate Block:** Press **`cmd/ctrl`** +  **`D`**

### Block types

Do these at the beginning of a new line to create these block types

- **Bulleted List:** Type **`+`** followed by **`space`**
- **To-Do Checkbox**: Type **`[]`**
- **Numbered List:** Type **`1.`**, **`a.`**, or **`i.`** followed by **`space`**
- **Divider:** Type **`---`**  (Three dashes in a row.)
- **Toggle**: Type **`>`** followed by **`space`**
- **Quote:** Type **`"`** followed by **`space`**
- **Headers:** Type **`#`** followed by **`space`** for H1 H1 heading; **`##`** followed by **`space`** for H2; and **`###`** followed by **`space`** for H3 sub-heading.

## To Create Mentions and Reminders

- **Mention a person:** Type **`@`** and another workspace member's name
- **Mention a page:** Type **`@`** and the name of another page in your workspace to create a link to it inline
- **Mention a date:** Type **`@`** and a date in any format (or "yesterday," "today" or "tomorrow," or even "next Wednesday")
- **Add a reminder:** Type **`@remind`** followed by a date in any format (including "yesterday," "today," "tomorrow," etc.). You can click on the link that appears to adjust the date and exact time you want to be reminded
- **Just an @ Sign:** Hit **`esc`** to dismiss the @-command menu

## To Add or Embed Media

- **Pictures:** **`/image`**
- **In-line PDFs:** **`/pdf`**
- **Web Bookmark: `/book`**
- **Video (Upload or Embed): `/video`** - works for YouTube, Vimeo, and mp4 files
- **Audio (Upload or Embed): `/audio`** works for SoundCloud, Spotify, and mp3 files
- **Files (Upload) :`/file`** lets you upload any file from your computer or create an embed.
- **Everything Else: `/embed`** lets you add any one of the 500+ embeds that work with Notion.

---

**Questions?** Reach out to Kristen Lowe on Slack or at kristen.lowe@hinge.co