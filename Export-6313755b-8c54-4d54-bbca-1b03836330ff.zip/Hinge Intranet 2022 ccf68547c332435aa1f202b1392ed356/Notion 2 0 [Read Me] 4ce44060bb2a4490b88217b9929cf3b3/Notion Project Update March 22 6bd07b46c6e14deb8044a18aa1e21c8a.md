# Notion Project Update: March 22

> *Status updates, answers to recent questions, and new resources*
> 

---

## Essential Updates

- *You have permission to edit whatever you want for now. Please be mindful as you edit!*
- *When you make choices about page design, you should consider who is going to look at that page and what needs/questions will bring them there (guidance below)*
- *Kristen will be OOO until 3/30 so Hannah Greene is your Notion POC between 3/23-3/30*

## Status Update #2: migration status, permissions, vacation

- **All content has officially been migrated to Notion 2.0** (!!!) and the old intranet has been deprecated. While we used a diligent mapping system to migrate content, if you think something has been lost or accidentally deleted, reach out. All content is recoverable.
- **We are working on a permissions structure,** and you can read all about it below. Setting up new permissions is a slow and manual process, but it is underway.
- ***However*, until everything is ready... we’re going to grant ubiquitous editing access.** Permission limbo is full of inconveniences. I hear you. So, between 3/21 and our official Notion 2.0 launch, we’ll be opening editing permissions to everyone. We will have to fly back through permissioning turbulence again soon, but I’m working on making it as easy as possible. Thanks for your feedback and patience. Stay tuned.
- **Hannah Greene will be your interim Notion guru from 3/23-3/30.** I’m headed to Mexico to think about tacos instead of page structures and information frameworks for a while. While I’m out, reach out to Hannah with any urgent questions or needs.
- **Notion working sessions**. To support your page building endeavors, I’m inviting you to put time on my calendar to build/update your Notion pages together. If you want guidance, creative partnership, or just a buddy to do updates with, my calendar is up-to-date and any white space is yours. Please use it!

Have a great week, friends 🙂
*Kristen* 

## March’s FAQs

- **Do I need to update what my page looks like if the content isn’t changing?**
    
    Yes, probably. We are trying to establish visual consistency across all of our Notion pages and create clear visitor journeys (more on that below). Beyond Home Pages, there are no strict templates, but if you answer “no” to any of the following questions, you’ll need to give your page a tune-up:
    
    - Does my page create a clear and intuitive path to information for both people who are familiar with the page content AND people who aren’t?
    - Could a brand new employee navigate my page with ease?
    - Does my page look consistent with the [**Style & Design Rules**](Style%20&%20Design%20Rules%202a541445689e44d49a15de6a44cec452.md) for Notion 2.0?
- **What Notion terminology should I know while updating pages?**
    - **Team:** Any group of people smaller than the full company. “Team” is used to characterize the size of the group of people, not the nature of it.
    - **Discipline**: Teams housed within a department that refer to people who work with the same knowledge, skillset, and goals (even if they apply those skillsets and achieve those goals for different groups). Design, backend engineering, PR, and DEI are examples of disciplines.
    - **Resources**: Any tool, link, template, or guide that can help people who are *not* part of a team understand or collaborate with that team.
    - **___ Hub**: A home for information that is only relevant for members of a team. To decide if someone belongs in a “Hub” page, ask yourself if people outside of your team would regularly need to access that resource/info. If not, it belongs in the Hub space, not the Resources space.
- **OK, but what goes in group/workstream pages vs department/discipline pages?**
    
    In Hinge’s new Group structure, many employees are onboarded into multiple org structures: departments, disciplines, groups, and workstreams. 
    
    As you choose where to place information, the easiest way to decide where something goes is to ask who the relevant audience is. For example, “is this content relevant to *everyone* in this department or just my discipline?” or “is this content relevant to my workstream or does it apply to everyone in the group?” The goal is to keep things in the place they are most relevant to. If you’re describing norms or sharing a roadmap that applies to a whole group but not a whole department, that information goes on the group page. If you’re sharing templates that are relevant to a singular discipline, share them on the discipline page. 
    
    And if you have questions... ask Kristen!
    
- **How are we going to update things going forward?**
    
    We’re still finalizing Notion 2.0 governance, but starting in May, all pages must be reviewed by their owners once a month at minimum. We will use a recurring calendar notification to remind people to update their pages. 
    
    Note, the monthly requirement is a floor not a ceiling. You are encouraged to update your Notion pages as frequently as required to keep information current and accurate. 
    

## Editing Permissions: Future State Overview

Along with the Notion 2.0 launch, we are introducing a new Permissions process. While we previously had no strict guidance for how people could edit and access pages, we will me implementing guidance to narrow editing permissions (don’t worry, viewing permissions are totally unchanged). **TL;DR** **you can access pages where you are the owner of content within that page or you manage the content owners.** In more detail, here’s what you should know: 

### **Who can edit what?**

- **Group** **leads** can edit all content within their Group’s page
- **All workstream members** can edit content within their workstream’s page
- **Department leads** can edit all content within their department’s page
- **All discipline members** can edit content within their discipline’s page
- **Designated page owners** can edit select pages they’re responsible
- **All Hinge employees** can edit archive channels

### **What can’t people edit?**

- **Workstream members** cannot edit other workstreams’ pages
- **Group members** cannot edit group home pages (only group leads will be able to edit a group’s main page)
- **Discipline owners** cannot edit other disciplines’ pages
- **Only designated page owners** and Notion admins can edit **About**, **Office**, and **Resources** pages

### Is all this ***really* necessary?**

In short, *maybe not.* But I want us to try it. Codifying permissioning rules will help solve several problems employees flagged with Notion 1.0: misplaced content, accidental deletions, obsolete information, and duplicative pages to name a few. More importantly, it helps us set a foundation for **disciplined page ownership and updating**, which is essential to keeping our internet accurate and relevant!

If after a few months we find that permissioning rules are causing more headache than they’re worth, we’ll switch it up. Our Notion norms will *always* be responsive to our company needs, but this will be our first attempt at managing a more mature Intranet site. 

## Designing for Visitor Journeys

### What are visitor journeys?

There are many frameworks for approaching intranet design and structure, but to ensure we build an Intranet that serves Hinge employees’ actual information needs, Notion 2.0 is built around the idea of user journeys: the paths to and through Notion that employees *actually* follow to get the information they need.

Our approach to designing the site structure was: identify the different visitor personas of intranet users, understand when they’re using Notion and what they need from it, build a site that serves those needs. 

### Visitor Personas @ Hinge

Dozens of unique questions and motivations might draw Hinge employees to our intranet. We can’t account for all of these, but we can group general categories of visitors to make sure we’re accommodating as many visitor journeys as possible. At Hinge, there are two main qualities that differentiate visitors from each other: if they’re onboarding or already for familiar with Hinge, and if they’re looking for information about their own team or someone else’s. 

|  | Onboarding | Established |
| --- | --- | --- |
| Team member | TM/O | TM/E |
| Non-team member | NT/O | NT/E |

*When designing notion pages, consider these different visitor personas and what they need from your page*

Consider what makes these visitors similar and different. For an **onboarding employee**, site navigation is more difficult than it is for established employees. Names, labels, and paths to information have to be intuitive and jargon-free for an onboarding employee to find them. For **established employees**, Notion is likely a storage place where they own and update documented work, so they need accessible and organized archives. An effective Intranet can support both of these visitor types as long as we consider who is coming to which pages and why. Below is a list of the *general* needs for Hinge’s different user personas that can guide how we name and organize Notion content:

- **All employees**: need access to basic info about company norms, policies, and progress
- **NT/E:** Employees that are visiting Notion pages for teams they are not on need clear and appropriately detailed information about how that team works and when/how NT employees can work with them. They also are likely to want insights into the status of a team’s active work.
- **NT/O:** Non-team employees in onboarding need enough information to understand the general structure and function of different parts of the organization as well as how to engage with people and teams they will work with cross-functionally.
- **TM/O:** For every team, onboarding employees need information specific to the teams they’re on (discipline, group, workstream, etc.) that teaches them the ways of working, tools, and processes unique to their teams.
- **TM/E:** Every team produces artifacts that need to be archived and organized to create a clear record of historical decision-making. Team members need accessible and up-to-date locations for storing artifacts, documenting information about their work, and centralizing resources and tools that support their work.

### How do we design for visitor journeys?

To build a page that supports visitors’ journeys, the best way to start is by asking the following questions: 

- Who would be looking for this information?
- What circumstance or situation would bring them to this page?
- What level of detail do they need to get what they’re looking for?

Once you’ve identified those answers, you can do the following to make sure your page supports your visitor’s path and needs:

- Make sure someone can clearly identify what’s on a page by using headers and descriptions
- Keeping the most frequently used/read information in obvious clear places, likely at the top
- Make extra detail available but not immediately visible by embedding pages or using toggles (this lets people who only need a *little* detail access it without getting overwhelmed while still providing exhaustive detail for those who need it)

Play around, put yourself in the page visitor’s shoes, and if you have question.... ask Kristen 🙂

---

*If you made it this far, just saying thanks for your interest in Notion and your readership - Kristen*