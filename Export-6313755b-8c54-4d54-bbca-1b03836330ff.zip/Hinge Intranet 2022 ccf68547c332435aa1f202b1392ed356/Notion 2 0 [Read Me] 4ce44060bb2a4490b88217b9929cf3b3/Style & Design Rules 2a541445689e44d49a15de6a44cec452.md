# Style & Design Rules

---

*Have some fun designing and upgrading pages while following the following rules and guidelines & using templates when required.*

## Style Rules

*Style rules apply across the entire 2.0 site to ensure our intranet feels clean, consistent, and accessible.* 

**Headers:** Always use ****the beige/light pink header common across verified Intranet pages

---

**Font:** Always standard Notion font. Never underlined. Bolded for **emphasis**. *Italic text* is for meta-commentary. It remarks on what is on the page or directs the reader. It is not actual page content. 

---

**Icons:** Every page should have a black and white icon at the top. Icons used within pages should also be black and white for consistency. To find icons, you can search [Flat Icon](https://www.flaticon.com/). 

---

**Colors:** Use black text for all page content and grey text to de-emphasize.  Use red or purple text very selectively to emphasize or differentiate content.

---

**Dividers:** Every page should have a divider at the top and bottom. The only text below the bottom divider should be legal notices and page owner details. They can also be used functionally to separate text. Like in this list. 

## **Design Principles**

**Content dictates style.**

> We make design choices that clarify and support the content we’re trying to share. We are form over fashion, and we prioritize clear reader journeys through pages over stylish design.
> 

**Be consistent.**

> Consistency in formatting helps viewers understand and differentiate page contents. We are creative but consistent in our page design, and we use like formatting to convey like information.
> 

**Aim for clean and uncluttered.**

> Thoughtful design prevents pages from being overwhelming or unnavigable. We use white space, toggles, and intentional layout choices to create pages that feel legible and clean.
> 

## Design Guidelines

### General Rules of the Road

Use multiple block types to make pages interesting, don’t be afraid to play around with special block types, and whatever you do - do it consistently. 

### Columns and Block Arrangement

Columns and different block arrangements can make a page feel dynamic, conserve space, add white space where needed, or just make a page fun. Here are some guidelines.

- Replicate templated layouts where possible. Using templated formats for showing principles, sharing FAQs or building glossaries can save you time and keep our site clean.
- Prioritize text/paragraph integrity over design. If using three columns crowds the content, don’t do it!

- Hold onto white space. White space is visually important for people who are trying to process text. Use columns to break up giant blocks of text (like this page does)
- Don’t overthink it. Notion is fun. If the content is clear and accessible, your work is done.

### To Toggle, or Not to Toggle

- That is the question.
    
    Toggles and Toggle headers are great options when you need to share a lot of text, but you’re not sharing a full “page” worth of information. Here are some soft guidelines:
    
    - When addressing a subject with different sections and sub-heads, consider making it a standalone page.
    - If you’re just sharing multiple paragraphs of text and what to preserve white space on a home page, consider making it a toggle.
    - Toggles are also great for pages where there’s information that not all page viewers will need to see and only the people who are extra curious will need to expand the full text.

### **Using Special Blocks**

**Quotes:** Are useful for more than just quotes. We also use them to share principles, create lists, and summarize glossaries. Play around with these

**Dividers:** can help break up information and should always indicate the beginning and end of a page. Use sparingly, but don’t shy away from inserting lines to help separate information and make it clearer.

**Callouts:** Are best used as actual call-outs. Put CTAs, important notes, and other things you want to emphasize in them. Only use grey, purple, or read backgrounds. If you do use them, please copy and paste the block below or manually insert a black icon. This helps us keep Notion accessible. 

<aside>
<img src="https://cdn-icons-png.flaticon.com/512/73/73169.png" alt="https://cdn-icons-png.flaticon.com/512/73/73169.png" width="40px" />

</aside>

---

**Questions?** Reach out to Kristen Lowe on Slack or at kristen.lowe@hinge.co