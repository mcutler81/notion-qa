# Organization

---

**Last Update:** November 2021

**Point of Contact:** Erin White (Senior People Specialist)

**Hinge Org Chart**

*To view Hinge's entire org chart, you can log into LucidChart with your Hinge email. If you have trouble accessing it, please reach out to Gino Negron (IT Support Engineer)*

[Click here to access the Org Chart.](https://app.lucidchart.com/documents/edit/4bfebc85-8959-4fe8-a494-9029dfad3261/0_0#?folder_id=home&browser=icon&sort=saved-desc)

**2022 Groups Update**

*In November 2021, Hinge updated the Group structure that organized work in 2020 to introduce workstreams (effective January 2022). As Hinge scales, workstreams enable focused work and autonomous team work across Product, Tech, and Community.*

*The Groups and Workstreams organization are laid out below. For detailed information about changes in Product, Community, and Tech and the associated changes, [click here to see the November 2021 Evolving Groups Presentation](https://docs.google.com/presentation/d/1hhLIn7kga5eQ-1es-y5LN2p28Y0eF3DJLSt_fx3mraE/edit#slide=id.gfcea94bb35_4_478) or review the [Evolving Groups FAQ](https://docs.google.com/document/d/1p9EPWrSXjhbImMYl0HsVysRPl0HhIbAGEeMmFclU0AA/edit#).*

**2022 Groups and Workstreams**

*Product Org: Growth, Experience*

*Tech Org: Engineering, Data, Nexus (new)*

*Community Org:*

![Screen Shot 2021-11-05 at 8.28.07 AM.png](Organization%20187e0ce184d74ee9b4898f8dae6a0e61/Screen_Shot_2021-11-05_at_8.28.07_AM.png)

**Product Workstream & Group Staffing**

*Under the Workstream model, workstreams and groups will be formed in the following ways:*

1. Each Group will have a Product, Design, Engineering, and Data Science lead to drive Group alignment. Groups will also have designers, a project manager, a data analyst, and a CX lead.
2. A PM, engineers, and data scientists will be fully assigned to individual workstreams (data scientist and engineer numbers will vary across workstreams)
3. Engineering managers, Research, QA, and Data Engineering will be assigned to a pair of workstreams to load balance.

![Screen Shot 2021-11-05 at 8.28.20 AM.png](Organization%20187e0ce184d74ee9b4898f8dae6a0e61/Screen_Shot_2021-11-05_at_8.28.20_AM.png)

[Workstream HotSpots](Organization%20187e0ce184d74ee9b4898f8dae6a0e61/Workstream%20HotSpots%2064a12c3c19cf4f868df99e08fa6873c5.md)